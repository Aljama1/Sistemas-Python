base = float(input("Dime la base:"))
altura = float(input("Dime la altura:"))
perimetro = 2 * base + 2 * altura
area = base * altura
print("Resultado: Area=%.2f Perimetro=%.2f" % (area, perimetro))
