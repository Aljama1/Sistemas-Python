import os
a = float (input ('a: '))
b = float (input ('b: '))
c = float (input ('c: '))
promedio=(a+b+c)/3
print ('La media es: ' + repr (promedio))
print ()
os.system ('pause')