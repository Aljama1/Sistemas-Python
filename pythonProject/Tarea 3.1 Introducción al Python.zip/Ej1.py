nombre = input("Ingresa tu nombre: ")
print("Hola ",nombre," buenos dias")