num1=float(input("Numero1:"))
num2=float(input("Numero2:"))
print ('Suma:%d,resta:%d,multiplicacion:%d,division:%.2f' % (num1 + num2, num1 - num2, num1 * num2, num1 / num2))