fahrenheit = int(input('¿Cuantos grados Farenheit hacen? '))
celsius = (fahrenheit - 32) * 5.0/9.0
print('{} entonces son {} grados Celsius '.format(fahrenheit, celsius))